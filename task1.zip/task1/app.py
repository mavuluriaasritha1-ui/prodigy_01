from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

app.secret_key = 'your_secret_key'  # Required for session management
app.config['MONGO_URI'] = "mongodb://localhost:27017/internship"
mongo = PyMongo(app)

@app.route('/')
def home():
    if 'user' in session:
        return render_template('home.html', user=session['user'])  # Render home.html with user info
    return redirect(url_for('login'))  # Redirect to login if not logged in

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html')  # Render signup form

    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not password:
        return jsonify({"message": "Username and password are required."}), 400

    if mongo.db.users.find_one({"username": username}):
        return jsonify({"message": "Username already exists."}), 400

    hashed_password = generate_password_hash(password)
    mongo.db.users.insert_one({"username": username, "password": hashed_password, "email": email})

    return jsonify({"message": "User registered successfully."}), 201

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')  # Render login form

    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"message": "Username and password are required."}), 400

    user = mongo.db.users.find_one({"username": username})

    if not user or not check_password_hash(user['password'], password):
        return jsonify({"message": "Invalid username or password."}), 401

    # Store user in session
    session['user'] = {'username': user['username'], 'email': user['email']}

    # Redirect to home.html after successful login
    return jsonify({"message": "Login successful.", "redirect": url_for('home')}), 200

@app.route('/user-info', methods=['GET'])
def user_info():
    if 'user' in session:
        return jsonify(session['user'])  # Return user info
    return jsonify({'error': 'Not logged in'}), 401

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully', "redirect": url_for('login')}), 200

if __name__ == '__main__':
    app.run(debug=True)
